# Deploying the App (manual steps)

## Vercel
1. Create a Vercel account.
2. Import project from your Git repository or drag & drop.
3. Set build command: `npm run build`
4. Output directory: `dist`
5. Deploy.

## Netlify
1. Create a Netlify site, link the repo.
2. Build command: `npm run build`
3. Publish directory: `dist`
4. Deploy.

Note: This project uses a static JSON file `public/companies.json` — it will be served from the root (e.g. https://your-site.com/companies.json).
