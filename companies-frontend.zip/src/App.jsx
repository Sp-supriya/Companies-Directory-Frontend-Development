import React from 'react'
import CompanyTable from './components/CompanyTable'

export default function App(){
  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <header className="max-w-6xl mx-auto mb-6">
        <h1 className="text-3xl font-bold">Companies Directory</h1>
        <p className="text-gray-600 mt-1">Browse, search and filter companies (mock API).</p>
      </header>
      <main className="max-w-6xl mx-auto">
        <CompanyTable />
      </main>
    </div>
  )
}
