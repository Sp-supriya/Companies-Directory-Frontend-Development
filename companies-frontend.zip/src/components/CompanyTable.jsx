import React, {useEffect, useState, useMemo} from 'react'

function Loader(){ return <div className="py-8 text-center">Loading companies...</div> }
function Error({message}){ return <div className="py-8 text-center text-red-600">Error: {message}</div> }

export default function CompanyTable(){
  const [companies, setCompanies] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const [query, setQuery] = useState('')
  const [location, setLocation] = useState('All')
  const [industry, setIndustry] = useState('All')
  const [sortBy, setSortBy] = useState('name')
  const [page, setPage] = useState(1)
  const perPage = 5

  useEffect(()=>{
    setLoading(true)
    fetch('/companies.json')
      .then(r=>{
        if(!r.ok) throw new Error('Failed to fetch companies.json (serve from /public)')
        return r.json()
      })
      .then(data=>{
        setCompanies(data)
        setError(null)
      })
      .catch(err=>{
        setError(err.message)
      })
      .finally(()=>setLoading(false))
  },[])

  const locations = useMemo(()=>{
    const s = new Set(companies.map(c=>c.location))
    return ['All', ...Array.from(s)]
  },[companies])

  const industries = useMemo(()=>{
    const s = new Set(companies.map(c=>c.industry))
    return ['All', ...Array.from(s)]
  },[companies])

  const filtered = useMemo(()=>{
    let list = companies.slice()
    if(query) list = list.filter(c=> c.name.toLowerCase().includes(query.toLowerCase()) || (c.website||'').toLowerCase().includes(query.toLowerCase()))
    if(location !== 'All') list = list.filter(c=> c.location === location)
    if(industry !== 'All') list = list.filter(c=> c.industry === industry)
    if(sortBy === 'name') list.sort((a,b)=> a.name.localeCompare(b.name))
    else if(sortBy === 'employees') list.sort((a,b)=> b.employees - a.employees)
    return list
  },[companies, query, location, industry, sortBy])

  const totalPages = Math.max(1, Math.ceil(filtered.length / perPage))
  const pageItems = filtered.slice((page-1)*perPage, page*perPage)

  useEffect(()=>{ if(page > totalPages) setPage(1) },[totalPages])

  if(loading) return <Loader />
  if(error) return <Error message={error} />

  return (
    <div className="bg-white shadow rounded p-4">
      <div className="flex flex-col md:flex-row md:items-end md:gap-4 mb-4">
        <div className="flex-1">
          <label className="block text-sm font-medium text-gray-700">Search</label>
          <input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search name or website" className="mt-1 block w-full border rounded p-2" />
        </div>
        <div className="w-48">
          <label className="block text-sm font-medium text-gray-700">Location</label>
          <select value={location} onChange={e=>setLocation(e.target.value)} className="mt-1 block w-full border rounded p-2">
            {locations.map(loc=> <option key={loc} value={loc}>{loc}</option>)}
          </select>
        </div>
        <div className="w-48">
          <label className="block text-sm font-medium text-gray-700">Industry</label>
          <select value={industry} onChange={e=>setIndustry(e.target.value)} className="mt-1 block w-full border rounded p-2">
            {industries.map(ind=> <option key={ind} value={ind}>{ind}</option>)}
          </select>
        </div>
        <div className="w-48">
          <label className="block text-sm font-medium text-gray-700">Sort</label>
          <select value={sortBy} onChange={e=>setSortBy(e.target.value)} className="mt-1 block w-full border rounded p-2">
            <option value="name">Name (A → Z)</option>
            <option value="employees">Employees (desc)</option>
          </select>
        </div>
      </div>

      <div>
        <table className="w-full table-auto border-collapse">
          <thead>
            <tr className="text-left">
              <th className="pb-2">Name</th>
              <th className="pb-2 hidden md:table-cell">Industry</th>
              <th className="pb-2">Location</th>
              <th className="pb-2 hidden sm:table-cell">Employees</th>
              <th className="pb-2">Website</th>
            </tr>
          </thead>
          <tbody>
            {pageItems.map(c=>(
              <tr key={c.id} className="border-t">
                <td className="py-3">{c.name}</td>
                <td className="py-3 hidden md:table-cell text-sm text-gray-600">{c.industry}</td>
                <td className="py-3">{c.location}</td>
                <td className="py-3 hidden sm:table-cell">{c.employees}</td>
                <td className="py-3"><a className="text-blue-600" href={c.website} target="_blank" rel="noreferrer">Visit</a></td>
              </tr>
            ))}
            {pageItems.length === 0 && (
              <tr><td colSpan="5" className="py-8 text-center text-gray-500">No companies match your filters.</td></tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="mt-4 flex items-center justify-between">
        <div className="text-sm text-gray-600">Showing {filtered.length} result(s)</div>
        <div className="flex items-center gap-2">
          <button onClick={()=>setPage(p=>Math.max(1,p-1))} className="px-3 py-1 border rounded" disabled={page===1}>Prev</button>
          <div>Page {page} / {totalPages}</div>
          <button onClick={()=>setPage(p=>Math.min(totalPages,p+1))} className="px-3 py-1 border rounded" disabled={page===totalPages}>Next</button>
        </div>
      </div>
    </div>
  )
}
