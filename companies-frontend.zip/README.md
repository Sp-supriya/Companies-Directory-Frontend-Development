# Companies Directory — Frontend

This is a React + Vite frontend that displays a list of companies (mock API via `public/companies.json`) with filtering, sorting and pagination.

## Features
- Search by name/website
- Filter by location and industry
- Sort by name or employees
- Pagination (5 items per page)
- Responsive table layout

## How to run locally
1. Install Node.js (>=16) and npm.
2. In project root:
   - `npm install`
   - `npm run dev`
3. Open http://localhost:5173

## Deployment
You can deploy to Vercel / Netlify / Render:
- For Vercel: just `vercel` from the project root or connect the repo; build command: `npm run build`, output directory: `dist`.
- For Netlify: build command `npm run build`, publish directory `dist`.

`public/companies.json` acts as the mock API.

## What I included in the zip
- Full frontend source (src/)
- public/companies.json (mock API)
- preview.html — quick static preview that works without building
- deploy_instructions.md — step-by-step deploy notes
